* Savoir-faire Linux <support@savoirfairelinux.com>
* Gervais Naoussi <gervaisnaoussi@gmail.com>
* Eugen Don <eugen.don@don-systems.de>
* Jose Maria Alzaga <jose.alzaga@aselcis.com>
* Iván Todorovich <ivan.todorovich@gmail.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda

* `Trobz <https://trobz.com>`_:

  * Dung Tran <dungtd@trobz.com>
* Yvan Dotet <yvan.dotet@logicasoft.eu>
