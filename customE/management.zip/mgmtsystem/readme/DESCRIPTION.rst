This module is the basis of any management system applications:

* audit reports
* nonconformities
* immediate actions
* preventive actions
* corrective actions
* improvement opportunities
