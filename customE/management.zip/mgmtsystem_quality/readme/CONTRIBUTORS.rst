* Luk Vermeylen <luk@allmas-it.be>
* Daniel Reis <dgreis@sapo.pt>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* Gervais Naoussi <gervaisnaoussi@gmail.com>
* Open Source Integrators <https://www.opensourceintegrators.com>

  * Maxime Chambreuil <mchambreuil@opensourceintegrators.com>

* Eugen Don <eugen.don@don-systems.de>
* Jose Maria Alzaga <jose.alzaga@aselcis.com>
* Guadaltech <https://www.guadaltech.es>

  * Fernando La Chica <fernando.lachica@guadaltech.es>
* Yvan Dotet <yvan.dotet@logicasoft.eu>
