* Go to "Management System -> Configuration -> Settings"
* Under "Applications" enable "Actions" flag
* Save
