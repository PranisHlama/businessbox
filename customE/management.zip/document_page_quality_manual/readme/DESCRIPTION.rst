This module provides a quality manual template. The template has the same structure as the ISO 9001 standard.
