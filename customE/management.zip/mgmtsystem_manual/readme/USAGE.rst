To use this module, you need to:

* go to Management Systems > Documentation > Manuals
* Create a new page based on existing templates or create your own templates.
