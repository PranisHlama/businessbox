This module adds a menu item "Documentation" and is a dependency of:

* document_page_environment_manual
* document_page_health_safety_manual
* mgmtsystem_quality.
