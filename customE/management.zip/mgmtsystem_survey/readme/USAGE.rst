To use this module, you need to:

#. Publish the survey on the web (using the website module) or
#. Print the survey and send it by email or
#. Call your customer and go through the list of questions over the phone
