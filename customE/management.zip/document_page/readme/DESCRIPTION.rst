This module allows you to write web pages for internal documentation.
