This module depends on module knowledge. So make sure to have it in your addons list.
